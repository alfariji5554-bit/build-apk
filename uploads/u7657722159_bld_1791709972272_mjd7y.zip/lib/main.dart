import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() => runApp(const WebApp());
class WebApp extends StatelessWidget { const WebApp({super.key}); @override Widget build(BuildContext context) => MaterialApp(title: "webjb", debugShowCheckedModeBanner:false, theme: ThemeData(useMaterial3:true), home: const WebHome()); }
class WebHome extends StatefulWidget { const WebHome({super.key}); @override State<WebHome> createState()=>_WebHomeState(); }
class _WebHomeState extends State<WebHome> { late final WebViewController controller; @override void initState(){ super.initState(); controller=WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..setNavigationDelegate(NavigationDelegate(onWebResourceError:(e){}))..loadRequest(Uri.parse("https://lynk.id/fisbu")); } @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:WebViewWidget(controller:controller))); }

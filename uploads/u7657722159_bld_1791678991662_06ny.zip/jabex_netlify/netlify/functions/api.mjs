const ORDER = ["gemini", "groq", "huggingface", "deepseek", "openrouter"];
const PROVIDERS = {
  gemini: { key: process.env.GEMINI_API_KEY || "", model: process.env.GEMINI_MODEL || "gemini-2.5-flash", base: "https://generativelanguage.googleapis.com/v1beta" },
  groq: { key: process.env.GROQ_API_KEY || "", model: process.env.GROQ_MODEL || "openai/gpt-oss-120b", base: "https://api.groq.com/openai/v1" },
  huggingface: { key: process.env.HUGGINGFACE_API_KEY || "", model: process.env.HF_MODEL || "openai/gpt-oss-120b:fastest", base: "https://router.huggingface.co/v1" },
  deepseek: { key: process.env.DEEPSEEK_API_KEY || "", model: process.env.DEEPSEEK_MODEL || "deepseek-chat", base: "https://api.deepseek.com" },
  openrouter: { key: process.env.OPENROUTER_API_KEY || "", model: process.env.OPENROUTER_MODEL || "openai/gpt-4o-mini", base: "https://openrouter.ai/api/v1" }
};
const SYSTEM_PROMPT = "Kamu adalah JABEXAI, asisten AI yang ramah, teliti, membantu, dan menjawab dalam bahasa yang digunakan pengguna.";
const json = (data, status=200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
function providerOrder(requested) { return requested && requested !== "auto" ? [requested, ...ORDER.filter(p => p !== requested)] : ORDER; }
function parsePath(url) { const p = new URL(url).pathname.split("/").filter(Boolean); return p[p.length - 1] || ""; }
function sse(event, data) { return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`; }
function normalizeMessages(messages) { return messages.slice(-30).map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content })); }
async function* parseSSE(resp, provider) {
  if (!resp.ok) throw new Error(`${provider}: HTTP ${resp.status} — ${(await resp.text()).slice(0, 400)}`);
  if (!resp.body) throw new Error(`${provider}: respons kosong`);
  const reader = resp.body.getReader(), decoder = new TextDecoder(); let buffer = "";
  while (true) {
    const { value, done } = await reader.read(); if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n"); buffer = lines.pop() || "";
    for (const raw of lines) {
      const line = raw.trim(); if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim(); if (data === "[DONE]") return;
      try {
        const obj = JSON.parse(data);
        const text = provider === "gemini" ? (obj.candidates?.[0]?.content?.parts || []).map(x => x.text || "").join("") : obj.choices?.[0]?.delta?.content;
        if (typeof text === "string" && text) yield text;
      } catch {}
    }
  }
}
async function* callProvider(provider, messages, signal) {
  const cfg = PROVIDERS[provider];
  if (provider === "gemini") {
    const contents = messages.map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: Array.isArray(m.content) ? m.content.map(p => {
      if (p.type === "text") return { text: p.text };
      if (p.type === "image_url") { const match = p.image_url?.url?.match(/^data:(.*?);base64,(.*)$/); if (match) return { inlineData: { mimeType: match[1], data: match[2] } }; }
      return { text: "[Lampiran tidak didukung oleh model ini.]" };
    }) : [{ text: String(m.content ?? "") }] }));
    const resp = await fetch(`${cfg.base}/models/${cfg.model}:streamGenerateContent?alt=sse&key=${encodeURIComponent(cfg.key)}`, { method: "POST", signal, headers: { "content-type": "application/json" }, body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] }, contents, generationConfig: { temperature: 0.7 } }) });
    yield* parseSSE(resp, provider); return;
  }
  const resp = await fetch(`${cfg.base}/chat/completions`, { method: "POST", signal, headers: { "content-type": "application/json", authorization: `Bearer ${cfg.key}`, ...(provider === "openrouter" ? { "HTTP-Referer": "https://jabexai.netlify.app", "X-Title": "JABEXAI" } : {}) }, body: JSON.stringify({ model: cfg.model, messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages], stream: true }) });
  yield* parseSSE(resp, provider);
}
export default async (request) => {
  const route = parsePath(request.url);
  if (request.method === "GET" && route === "status") {
    return json({ app: "JABEXAI", defaultProvider: "auto", providers: Object.fromEntries(Object.entries(PROVIDERS).map(([k,v]) => [k, { configured: Boolean(v.key), model: v.model }])) });
  }
  if (request.method !== "POST" || route !== "chat") return json({ error: "Endpoint tidak ditemukan." }, 404);
  let body; try { body = await request.json(); } catch { return json({ error: "Body JSON tidak valid." }, 400); }
  const messages = body?.messages;
  if (!Array.isArray(messages) || !messages.length) return json({ error: "Pesan tidak ditemukan." }, 400);
  const candidates = providerOrder(body.provider).filter(p => PROVIDERS[p]?.key);
  if (!candidates.length) return json({ error: "API key belum diisi. Tambahkan Environment Variables di Netlify lalu deploy ulang." }, 400);
  const controller = new AbortController();
  const stream = new ReadableStream({
    async start(controllerStream) {
      const encoder = new TextEncoder(); let emitted = false; const errors = [];
      const send = (event, data) => controllerStream.enqueue(encoder.encode(sse(event, data)));
      try {
        for (const provider of candidates) {
          try {
            send("provider", { provider });
            for await (const chunk of callProvider(provider, normalizeMessages(messages), controller.signal)) {
              emitted = true; send("message", { text: chunk });
            }
            send("done", { provider }); controllerStream.close(); return;
          } catch (err) {
            if (controller.signal.aborted) { controllerStream.close(); return; }
            errors.push(`${provider}: ${err?.message || "gagal"}`);
            if (emitted) { send("error", { error: err?.message || "Streaming terputus", partial: true }); controllerStream.close(); return; }
          }
        }
        send("error", { error: "Semua provider gagal. " + errors.join(" | ") }); controllerStream.close();
      } catch (err) { try { send("error", { error: err?.message || "Kesalahan server" }); controllerStream.close(); } catch {} }
    },
    cancel() { controller.abort(); }
  });
  return new Response(stream, { status: 200, headers: { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-cache, no-transform", "connection": "keep-alive", "x-accel-buffering": "no" } });
};

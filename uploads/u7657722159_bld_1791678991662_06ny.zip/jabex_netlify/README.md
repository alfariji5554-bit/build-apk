# JABEXAI — Netlify-ready (streaming)

Versi ini disiapkan untuk deploy di Netlify. Frontend tetap memakai UI neo-brutalist yang sama; endpoint `/api/chat` berjalan sebagai Netlify Function dan mengirim jawaban AI dalam **SSE streaming** agar teks muncul bertahap/live, dengan indikator berpikir yang sudah ada di UI.

## Deploy gratis ke Netlify

1. Ekstrak ZIP.
2. Unggah isi folder proyek ke repository GitHub baru (bukan hanya `public/`).
3. Di Netlify pilih **Add new site → Import an existing project**, lalu hubungkan repository GitHub.
4. Build settings: publish directory `public`; functions directory `netlify/functions`. `netlify.toml` sudah mengaturnya otomatis.
5. Buka **Site configuration → Environment variables** dan tambahkan satu atau beberapa variabel berikut. Isi value dengan API key baru dari dashboard penyedia:

| Variable | Kegunaan |
|---|---|
| `GEMINI_API_KEY` | Google Gemini |
| `GROQ_API_KEY` | GroqCloud |
| `HUGGINGFACE_API_KEY` | Hugging Face Inference Providers |
| `DEEPSEEK_API_KEY` | DeepSeek (opsional; mungkin berbayar) |
| `OPENROUTER_API_KEY` | OpenRouter (opsional) |
| `GEMINI_MODEL` | Opsional, default `gemini-2.5-flash` |
| `GROQ_MODEL` | Opsional, default `openai/gpt-oss-120b` |
| `HF_MODEL` | Opsional, default `openai/gpt-oss-120b:fastest` |
| `DEEPSEEK_MODEL` | Opsional, default `deepseek-chat` |
| `OPENROUTER_MODEL` | Opsional, default `openai/gpt-4o-mini` |

6. Setelah menyimpan environment variables, jalankan **Deploys → Trigger deploy → Clear cache and deploy site** (atau Trigger deploy). Key disimpan server-side, bukan di `public/`.
7. Buka URL Netlify dan coba kirim chat. Kalau provider gagal sebelum mengirim token, fungsi mencoba provider berikutnya. Jika sudah ada token yang terkirim lalu stream terputus, fallback tidak menggabungkan dua jawaban.

## Urutan otomatis

Gemini → Groq → Hugging Face → DeepSeek → OpenRouter, dengan provider yang memiliki API key saja yang dicoba. Kamu bisa memilih provider di Pengaturan. Free tier dan kuota bergantung pada penyedia, model, dan akun; tidak dijamin tanpa batas. Hugging Face model ID yang tersedia dapat berubah, jadi bila model default tidak tersedia, atur `HF_MODEL` ke model yang didukung oleh akun/provider-mu.

## Live streaming

Fungsi menggunakan Web `ReadableStream` dan Server-Sent Events untuk meneruskan token saat provider menghasilkannya. Netlify mendukung streaming response functions, tetapi batas eksekusi dan batas platform tetap berlaku. Bila respons panjang terputus, coba prompt lebih pendek atau provider lain.

## Catatan lampiran

UI menerima gambar, file teks/kode, dan rekaman mikrofon. Gemini mendukung input gambar dalam format yang dikirim oleh frontend. Lampiran PDF biner, video, dokumen Office, dan audio rekaman belum otomatis diekstrak/transkripsi pada versi ini; jangan menganggap semua format lampiran sudah dibaca model.

## Keamanan

- Jangan masukkan API key ke `public/app.js`, `index.html`, atau repository.
- Jangan commit file yang berisi key.
- Jika key pernah dikirim di chat atau terlihat publik, revoke dan buat key baru.
- Pasang proteksi/rate limit bila situs publik agar orang lain tidak menghabiskan kuota API kamu.

## Test lokal (opsional)

Perlu Node.js 18+ dan koneksi internet. Jalankan `npm install`, masukkan environment variables ke shell, lalu `npm run dev`. Tidak perlu menjalankan `npm start` pada hosting Netlify.

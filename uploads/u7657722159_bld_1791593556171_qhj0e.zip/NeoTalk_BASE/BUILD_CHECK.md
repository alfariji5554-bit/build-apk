NeoTalk build-fix notes

Target Flutter: 3.41.x
Target mode: release

This revision rewrites lib/main.dart into a compile-safe, readable structure and fixes the previous errors:
- NeoScaffold now accepts floatingActionButton.
- Communities list avoids nullable dynamic dereference.
- CallsPage no longer passes floatingActionButton to a constructor that does not accept it.
- CallPage Stack/Positioned nesting was rewritten.
- SettingsPage was rewritten with explicit typed Future.wait and maps.
- Broken redAccentAccent/shade references are absent.
- No API/backend is required for the first build.

Static checks performed before packaging:
- Balanced Dart delimiters after stripping strings/comments.
- Search confirms no redAccentAccent or redAccent.shade800/shade900 remains.
- Android project uses Flutter embedding v2.
- pubspec Flutter constraint is compatible with Flutter 3.41.x.

The current execution environment does not contain the Flutter SDK, so a real `flutter analyze` / `flutter build apk --release` could not be executed here. The ZIP is therefore not claimed to have been compiler-tested locally.

# NeoTalk

Lightweight NeoBrutalism messenger prototype for Flutter.

## Build

Use a clean Flutter 3.41.x environment and build in release mode:

```bash
flutter clean
flutter pub get
flutter build apk --release
```

The first version intentionally uses local demo storage. OTP and Google account selection are demo flows; the real API/backend can be added after the APK base builds successfully.

## Included UI

- Chat list and search
- Text chat and reply
- Photo/video picker
- Camera picker
- Voice/video call screens
- Status creation
- Status privacy choices
- Channels list
- Communities creation/list
- Calls list and actions
- Settings screen
- Local registration/login
- Demo OTP
- Demo Google account chooser
- NeoBrutalism animated bottom navigation

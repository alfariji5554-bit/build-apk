# NeoTalk API connection

The app reads its API base URL from the compile-time variable `NEOTALK_API_URL`.

Build for a public Pterodactyl API URL:
`flutter build apk --release --dart-define=NEOTALK_API_URL=https://YOUR-PUBLIC-API-DOMAIN`

Replace the example with your actual public API URL (no trailing slash). The default `http://127.0.0.1:3000` only works when the API is reachable on the same device/host at that address; it will not reach a remote Pterodactyl server.

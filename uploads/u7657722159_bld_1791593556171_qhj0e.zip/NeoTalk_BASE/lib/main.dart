import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'services/api_client.dart';
import 'services/local_store.dart';
import 'widgets/neo_nav_bar.dart';

const Color ink = Color(0xFF111111);
const Color paper = Color(0xFFF5F0E6);
const Color lime = Color(0xFF9BE15D);
const Color yellow = Color(0xFFFFD84D);
const Color pink = Color(0xFFFF6B9D);
const Color cyan = Color(0xFF73E5FF);
const Color orange = Color(0xFFFF9B54);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NeoTalkApp());
}

class NeoTalkApp extends StatefulWidget {
  const NeoTalkApp({super.key});

  @override
  State<NeoTalkApp> createState() => _NeoTalkAppState();
}

class _NeoTalkAppState extends State<NeoTalkApp> {
  bool? loggedIn;

  @override
  void initState() {
    super.initState();
    LocalStore.isLoggedIn().then((value) {
      if (mounted) {
        setState(() => loggedIn = value);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loggedIn == null) {
      return const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: paper,
          body: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NeoTalk',
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: paper,
        colorScheme: ColorScheme.fromSeed(
          seedColor: lime,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        splashFactory: InkSparkle.splashFactory,
      ),
      home: loggedIn! ? const Shell() : AuthScreen(onDone: _loggedIn),
    );
  }

  void _loggedIn() {
    if (mounted) {
      setState(() => loggedIn = true);
    }
  }
}

class NeoScaffold extends StatelessWidget {
  final Widget child;
  final String title;
  final List<Widget> actions;
  final Widget? leading;
  final Widget? floatingActionButton;
  final bool safe;

  const NeoScaffold({
    super.key,
    required this.child,
    required this.title,
    this.actions = const <Widget>[],
    this.leading,
    this.floatingActionButton,
    this.safe = true,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: paper,
      appBar: AppBar(
        backgroundColor: paper,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: leading,
        title: Text(
          title,
          style: const TextStyle(
            color: ink,
            fontWeight: FontWeight.w900,
            fontSize: 27,
            letterSpacing: -1,
          ),
        ),
        actions: actions,
      ),
      body: safe ? SafeArea(top: false, child: child) : child,
      floatingActionButton: floatingActionButton,
    );
  }
}

class NeoCard extends StatelessWidget {
  final Widget child;
  final Color color;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final BorderRadius radius;

  const NeoCard({
    super.key,
    required this.child,
    this.color = Colors.white,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.radius = const BorderRadius.all(Radius.circular(18)),
  });

  @override
  Widget build(BuildContext context) {
    final content = AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: ink, width: 3),
        borderRadius: radius,
        boxShadow: const [
          BoxShadow(color: ink, offset: Offset(5, 5), blurRadius: 0),
        ],
      ),
      child: child,
    );

    if (onTap == null) {
      return content;
    }
    return InkWell(
      onTap: onTap,
      borderRadius: radius,
      child: content,
    );
  }
}

class NeoButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback? onPressed;
  final Color color;
  final bool compact;

  const NeoButton({
    super.key,
    required this.text,
    required this.icon,
    this.onPressed,
    this.color = lime,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: compact ? 44 : 52,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, color: ink),
        label: Text(
          text,
          style: const TextStyle(color: ink, fontWeight: FontWeight.w900),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: ink,
          elevation: 0,
          side: const BorderSide(color: ink, width: 3),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  final VoidCallback onDone;

  const AuthScreen({super.key, required this.onDone});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = true;
  bool obscure = true;
  final username = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final identity = TextEditingController();
  final loginPassword = TextEditingController();

  @override
  void dispose() {
    username.dispose();
    email.dispose();
    password.dispose();
    identity.dispose();
    loginPassword.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (register) {
      if (username.text.trim().isEmpty ||
          email.text.trim().isEmpty ||
          password.text.length < 6) {
        _snack('Isi username, email, dan password minimal 6 karakter.');
        return;
      }

      try {
        final result = await ApiClient.register(
          username: username.text.trim(),
          email: email.text.trim(),
          password: password.text,
        );
        final user = (result['user'] is Map)
            ? Map<String, dynamic>.from(result['user'] as Map)
            : <String, dynamic>{};
        final token = result['token']?.toString() ?? '';
        if (token.isEmpty) throw ApiException('API tidak mengembalikan token login.');
        await LocalStore.saveSession(
          username: user['username']?.toString() ?? username.text.trim(),
          email: user['email']?.toString() ?? email.text.trim(),
          token: token,
        );
        widget.onDone();
      } catch (e) {
        _snack(e.toString().replaceFirst('ApiException: ', ''));
      }
    } else {
      if (identity.text.trim().isEmpty || loginPassword.text.isEmpty) {
        _snack('Isi username/email dan password.');
        return;
      }
      try {
        final result = await ApiClient.login(
          identity: identity.text.trim(),
          password: loginPassword.text,
        );
        final user = (result['user'] is Map)
            ? Map<String, dynamic>.from(result['user'] as Map)
            : <String, dynamic>{};
        final token = result['token']?.toString() ?? '';
        if (token.isEmpty) throw ApiException('API tidak mengembalikan token login.');
        await LocalStore.saveSession(
          username: user['username']?.toString() ?? identity.text.trim(),
          email: user['email']?.toString() ?? '',
          token: token,
        );
        widget.onDone();
      } catch (e) {
        _snack(e.toString().replaceFirst('ApiException: ', ''));
      }
    }
  }

  void _snack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: paper,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const NeoCard(
                    color: lime,
                    padding: EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'NEOTALK',
                          style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -2,
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Messenger komunitas dengan gaya NeoBrutalism.',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: NeoButton(
                          text: 'Daftar',
                          icon: Icons.person_add_alt_1,
                          color: register ? lime : Colors.white,
                          onPressed: () => setState(() => register = true),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: NeoButton(
                          text: 'Masuk',
                          icon: Icons.login,
                          color: !register ? cyan : Colors.white,
                          onPressed: () => setState(() => register = false),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  if (register) ...[
                    _field(username, 'Username', Icons.alternate_email),
                    _field(
                      email,
                      'Email',
                      Icons.mail_outline,
                      keyboard: TextInputType.emailAddress,
                    ),
                    _field(
                      password,
                      'Kata sandi',
                      Icons.lock_outline,
                      obscure: obscure,
                      suffix: IconButton(
                        icon: Icon(
                          obscure ? Icons.visibility : Icons.visibility_off,
                        ),
                        onPressed: () => setState(() => obscure = !obscure),
                      ),
                    ),
                  ] else ...[
                    _field(identity, 'Username atau email', Icons.person_outline),
                    _field(
                      loginPassword,
                      'Kata sandi',
                      Icons.lock_outline,
                      obscure: obscure,
                      suffix: IconButton(
                        icon: Icon(
                          obscure ? Icons.visibility : Icons.visibility_off,
                        ),
                        onPressed: () => setState(() => obscure = !obscure),
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  NeoButton(
                    text: register ? 'Buat akun' : 'Masuk ke NeoTalk',
                    icon: register
                        ? Icons.rocket_launch
                        : Icons.arrow_forward_rounded,
                    onPressed: submit,
                  ),
                  const SizedBox(height: 14),
                  const Row(
                    children: [
                      Expanded(child: Divider(thickness: 2, color: ink)),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Text(
                          'ATAU',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                      Expanded(child: Divider(thickness: 2, color: ink)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  NeoButton(
                    text: 'Lanjut dengan Google',
                    icon: Icons.account_circle,
                    color: yellow,
                    onPressed: _googleLogin,
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Register dan login terhubung ke NeoTalk API. Google OAuth akan aktif setelah Client ID Android/Web dikonfigurasi.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _googleLogin() async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: paper,
      builder: (_) => const GoogleChooser(),
    );

    if (picked == null) {
      return;
    }

    _snack('Google OAuth belum dikonfigurasi. Gunakan username/email + password terlebih dahulu.');
  }

  Widget _field(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool obscure = false,
    TextInputType? keyboard,
    Widget? suffix,
  }) {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: const BorderSide(color: ink, width: 3),
    );

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        keyboardType: keyboard,
        style: const TextStyle(fontWeight: FontWeight.w800),
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          suffixIcon: suffix,
          filled: true,
          fillColor: Colors.white,
          border: border,
          enabledBorder: border,
          focusedBorder: border,
        ),
      ),
    );
  }
}

class GoogleChooser extends StatelessWidget {
  const GoogleChooser({super.key});

  @override
  Widget build(BuildContext context) {
    const accounts = <String>[
      'neotalk.demo@gmail.com',
      'community.demo@gmail.com',
      'personal.demo@gmail.com',
    ];

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Pilih akun Google',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            ...accounts.map(
              (account) => ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(
                  account,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                onTap: () => Navigator.pop(context, account),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class OtpScreen extends StatefulWidget {
  final String email;
  final String? devCode;

  const OtpScreen({super.key, required this.email, this.devCode});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final code = TextEditingController();
  Timer? timer;
  int seconds = 45;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (seconds > 0) {
        setState(() => seconds--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: paper,
      appBar: AppBar(
        backgroundColor: paper,
        title: const Text(
          'Verifikasi OTP',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            NeoCard(
              color: yellow,
              child: Text(
                'Kode OTP dikirim ke ${widget.email}.' + (widget.devCode == null ? '' : '\nKode development: ${widget.devCode}'),
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
            const SizedBox(height: 18),
            TextField(
              controller: code,
              keyboardType: TextInputType.number,
              maxLength: 6,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w900,
                letterSpacing: 8,
              ),
              decoration: const InputDecoration(
                labelText: 'Masukkan kode',
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: ink, width: 3),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Kirim ulang ${seconds}s',
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            const Spacer(),
            NeoButton(
              text: 'Verifikasi',
              icon: Icons.verified_rounded,
              onPressed: () {
                final value = code.text.trim();
                if (value.length != 6) return;
                Navigator.pop(context, value);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;

  final pages = const <Widget>[
    ChatHome(),
    UpdatesPage(),
    CommunitiesPage(),
    CallsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: paper,
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NeoNavBar(
        currentIndex: index,
        onTap: (value) => setState(() => index = value),
        chatBadge: 0,
      ),
    );
  }
}

class ChatHome extends StatefulWidget {
  const ChatHome({super.key});

  @override
  State<ChatHome> createState() => _ChatHomeState();
}

class _ChatHomeState extends State<ChatHome> {
  final chats = <Map<String, dynamic>>[];

  String query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = chats
        .where(
          (chat) => chat['name']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()),
        )
        .toList();

    return NeoScaffold(
      title: 'NeoTalk',
      actions: [
        IconButton(
          icon: const Icon(Icons.camera_alt_outlined),
          onPressed: () => _snack('Kamera siap'),
        ),
        PopupMenuButton<String>(
          onSelected: _menu,
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'group', child: Text('Grup baru')),
            PopupMenuItem(value: 'community', child: Text('Komunitas baru')),
            PopupMenuItem(value: 'broadcast', child: Text('Siaran baru')),
            PopupMenuItem(value: 'linked', child: Text('Perangkat tertaut')),
            PopupMenuItem(value: 'star', child: Text('Berbintang')),
            PopupMenuItem(value: 'read', child: Text('Baca semua')),
            PopupMenuItem(value: 'settings', child: Text('Pengaturan')),
          ],
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: lime,
        foregroundColor: ink,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(17),
          side: const BorderSide(color: ink, width: 3),
        ),
        onPressed: () => _snack('Kontak baru / chat baru'),
        icon: const Icon(Icons.add_comment_rounded),
        label: const Text(
          'CHAT',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: TextField(
              onChanged: (value) => setState(() => query = value),
              decoration: InputDecoration(
                hintText: 'Cari chat favorit',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22),
                  borderSide: const BorderSide(color: ink, width: 3),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22),
                  borderSide: const BorderSide(color: ink, width: 3),
                ),
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                NeoButton(
                  text: 'Semua',
                  icon: Icons.chat,
                  compact: true,
                  color: lime,
                  onPressed: () {},
                ),
                const SizedBox(width: 8),
                NeoButton(
                  text: 'Favorit',
                  icon: Icons.star,
                  compact: true,
                  color: yellow,
                  onPressed: () {},
                ),
                const SizedBox(width: 8),
                NeoButton(
                  text: '+',
                  icon: Icons.add,
                  compact: true,
                  color: Colors.white,
                  onPressed: () {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
              itemCount: filtered.length,
              itemBuilder: (_, index) {
                final chat = filtered[index];
                final name = chat['name'].toString();
                final unread = chat['unread'] as int;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: NeoCard(
                    color: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChatPage(name: name),
                      ),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 27,
                          backgroundColor: chat['color'] as Color,
                          child: Text(
                            name.substring(0, 1).toUpperCase(),
                            style: const TextStyle(
                              color: ink,
                              fontWeight: FontWeight.w900,
                              fontSize: 20,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                chat['preview'].toString(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black54,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              chat['time'].toString(),
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            if (unread > 0)
                              Container(
                                margin: const EdgeInsets.only(top: 6),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 7,
                                  vertical: 3,
                                ),
                                decoration: BoxDecoration(
                                  color: lime,
                                  border: Border.all(color: ink, width: 2),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '$unread',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _menu(String value) {
    if (value == 'settings') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const SettingsPage()),
      );
    } else {
      _snack('$value dibuka');
    }
  }
}

class ChatPage extends StatefulWidget {
  final String name;

  const ChatPage({super.key, required this.name});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final picker = ImagePicker();
  final messages = <Map<String, dynamic>>[];
  String? replying;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: paper,
      appBar: AppBar(
        backgroundColor: paper,
        titleSpacing: 0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back),
        ),
        title: Row(
          children: [
            CircleAvatar(
              backgroundColor: cyan,
              child: Text(
                (widget.name.isNotEmpty ? widget.name.substring(0, 1) : "?"),
                style: const TextStyle(
                  color: ink,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                    ),
                  ),
                  const Text(
                    'online',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => _openCall(true),
            icon: const Icon(Icons.videocam_outlined),
          ),
          IconButton(
            onPressed: () => _openCall(false),
            icon: const Icon(Icons.call_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'settings') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()),
                );
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'search', child: Text('Cari')),
              PopupMenuItem(
                value: 'media',
                child: Text('Media, tautan, dan dokumen'),
              ),
              PopupMenuItem(value: 'wallpaper', child: Text('Wallpaper chat')),
              PopupMenuItem(
                value: 'settings',
                child: Text('Pengaturan chat'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: const EdgeInsets.all(14),
              itemCount: messages.length,
              itemBuilder: (_, reverseIndex) {
                final index = messages.length - 1 - reverseIndex;
                final message = messages[index];
                return _messageBubble(message);
              },
            ),
          ),
          if (replying != null)
            Container(
              color: yellow,
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  const Icon(Icons.reply),
                  Expanded(
                    child: Text(
                      replying!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => replying = null),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: () => _pick(false),
                    icon: const Icon(Icons.attach_file_rounded),
                  ),
                  IconButton(
                    onPressed: () => _pick(true),
                    icon: const Icon(Icons.photo_camera_outlined),
                  ),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 5,
                      decoration: InputDecoration(
                        hintText: 'Ketik pesan',
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(color: ink, width: 3),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(color: ink, width: 3),
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _send,
                    icon: const Icon(Icons.send_rounded, color: ink),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _messageBubble(Map<String, dynamic> message) {
    final mine = message['mine'] == true;
    final text = message['text'].toString();
    final file = message['file']?.toString();
    final reply = message['reply']?.toString();

    return GestureDetector(
      onLongPress: () => setState(() => replying = text),
      child: Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 330),
          margin: const EdgeInsets.only(bottom: 9),
          padding: const EdgeInsets.fromLTRB(13, 11, 13, 8),
          decoration: BoxDecoration(
            color: mine ? lime : Colors.white,
            border: Border.all(color: ink, width: 3),
            borderRadius: BorderRadius.circular(17),
            boxShadow: const [
              BoxShadow(color: ink, offset: Offset(3, 3), blurRadius: 0),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (reply != null && reply.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(7),
                  margin: const EdgeInsets.only(bottom: 7),
                  decoration: BoxDecoration(
                    color: Colors.black12,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    reply,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              if (file != null)
                Container(
                  height: 150,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: cyan,
                    border: Border.all(color: ink, width: 2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Icon(
                      file.toLowerCase().endsWith('.mp4')
                          ? Icons.play_circle_fill_rounded
                          : Icons.image_rounded,
                      size: 54,
                    ),
                  ),
                ),
              if (file != null) const SizedBox(height: 7),
              if (text.isNotEmpty)
                Text(
                  text,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.bottomRight,
                child: Text(
                  message['time'].toString(),
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openCall(bool video) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CallPage(name: widget.name, video: video),
      ),
    );
  }

  void _send() {
    final text = controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      messages.add({
        'text': text,
        'mine': true,
        'time': _time(),
        'reply': replying,
      });
      controller.clear();
      replying = null;
    });
  }

  Future<void> _pick(bool camera) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: paper,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text(
                'Foto',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              onTap: () => Navigator.pop(context, 'image'),
            ),
            ListTile(
              leading: const Icon(Icons.movie),
              title: const Text(
                'Video',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              onTap: () => Navigator.pop(context, 'video'),
            ),
            if (camera)
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text(
                  'Ambil foto dari kamera',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                onTap: () => Navigator.pop(context, 'camera'),
              ),
          ],
        ),
      ),
    );

    if (choice == null) return;

    final XFile? file = choice == 'video'
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(
            source: choice == 'camera'
                ? ImageSource.camera
                : ImageSource.gallery,
            imageQuality: 85,
          );

    if (file == null) return;

    setState(() {
      messages.add({
        'text': file.name,
        'mine': true,
        'time': _time(),
        'file': file.path,
        'reply': replying,
      });
      replying = null;
    });
  }

  String _time() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}.${now.minute.toString().padLeft(2, '0')}';
  }
}

class UpdatesPage extends StatefulWidget {
  const UpdatesPage({super.key});

  @override
  State<UpdatesPage> createState() => _UpdatesPageState();
}

class _UpdatesPageState extends State<UpdatesPage> {
  final picker = ImagePicker();

  final statuses = <Map<String, dynamic>>[];

  @override
  Widget build(BuildContext context) {
    return NeoScaffold(
      title: 'Pembaruan',
      actions: [
        IconButton(icon: const Icon(Icons.search), onPressed: () {}),
        PopupMenuButton<String>(
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'settings', child: Text('Pengaturan status')),
            PopupMenuItem(value: 'notifications', child: Text('Notifikasi')),
          ],
          onSelected: (value) {
            if (value == 'settings') {
              _showPrivacySettings();
            }
          },
        ),
      ],
      floatingActionButton: FloatingActionButton(
        backgroundColor: lime,
        foregroundColor: ink,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: ink, width: 3),
        ),
        onPressed: _createStatus,
        child: const Icon(Icons.camera_alt_outlined),
      ),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
        children: [
          const Text(
            'Status',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 180,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                NeoCard(
                  color: Colors.white,
                  padding: const EdgeInsets.all(10),
                  onTap: _createStatus,
                  child: const SizedBox(
                    width: 118,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 34,
                          backgroundColor: cyan,
                          child: Icon(Icons.person, size: 35, color: ink),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Tambah Status',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                        SizedBox(height: 5),
                        Icon(Icons.add_circle, color: lime),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ...statuses.map(
                  (status) => Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: NeoCard(
                      color: status['color'] as Color,
                      padding: const EdgeInsets.all(10),
                      onTap: () => _viewStatus(status),
                      child: SizedBox(
                        width: 118,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Spacer(),
                            Text(
                              status['name'].toString(),
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            Text(
                              status['text'].toString(),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Saluran',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              NeoButton(
                text: 'Jelajahi',
                icon: Icons.explore_outlined,
                compact: true,
                color: Colors.white,
                onPressed: () {},
              ),
            ],
          ),
          const SizedBox(height: 10),
          ...['Neo Gaming', 'Info Update', 'Creator Hub', 'Komunitas Lokal', 'Tech Daily'].map(
            (name) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: NeoCard(
                color: Colors.white,
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: lime,
                      child: Text(
                        name.substring(0, 1),
                        style: const TextStyle(
                          color: ink,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                          const Text(
                            'Update terbaru dari saluran ini',
                            style: TextStyle(
                              color: Colors.black54,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Text(
                      '99+',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _createStatus() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: paper,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Status teks'),
              onTap: () => Navigator.pop(context, 'text'),
            ),
            ListTile(
              leading: const Icon(Icons.photo),
              title: const Text('Status foto'),
              onTap: () => Navigator.pop(context, 'photo'),
            ),
            ListTile(
              leading: const Icon(Icons.movie),
              title: const Text('Status video'),
              onTap: () => Navigator.pop(context, 'video'),
            ),
          ],
        ),
      ),
    );

    if (choice == null) return;

    if (choice == 'text') {
      final textController = TextEditingController();
      final text = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: paper,
          title: const Text(
            'Status teks',
            style: TextStyle(fontWeight: FontWeight.w900),
          ),
          content: TextField(
            controller: textController,
            maxLines: 5,
            decoration: const InputDecoration(hintText: 'Tulis status...'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, textController.text.trim()),
              child: const Text('Lanjut'),
            ),
          ],
        ),
      );
      textController.dispose();
      if (text == null || text.isEmpty) return;
      _privacyDialog(text);
      return;
    }

    final XFile? file = choice == 'video'
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);

    if (file == null) return;
    _privacyDialog(file.name);
  }

  void _privacyDialog(String content) {
    String privacy = 'Semua kontak';

    showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: paper,
          title: const Text(
            'Privasi status',
            style: TextStyle(fontWeight: FontWeight.w900),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: ['Semua kontak', 'Kontak saya kecuali...', 'Bagikan hanya dengan...']
                .map(
                  (value) => RadioListTile<String>(
                    value: value,
                    groupValue: privacy,
                    title: Text(value),
                    onChanged: (selected) {
                      if (selected != null) {
                        setDialogState(() => privacy = selected);
                      }
                    },
                  ),
                )
                .toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () async {
                await LocalStore.setPrivacy(privacy);
                if (!mounted) return;
                setState(() {
                  statuses.insert(0, {
                    'name': 'Anda',
                    'text': content,
                    'color': lime,
                  });
                });
                Navigator.pop(dialogContext);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Status dibuat — $privacy')),
                );
              },
              child: const Text('Bagikan'),
            ),
          ],
        ),
      ),
    );
  }

  void _viewStatus(Map<String, dynamic> status) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: status['color'] as Color,
        title: Text(
          status['name'].toString(),
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        content: Text(
          status['text'].toString(),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showPrivacySettings() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: paper,
      builder: (_) => const SafeArea(
        child: Padding(
          padding: EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Privasi Status',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              SizedBox(height: 12),
              ListTile(
                leading: Icon(Icons.public),
                title: Text('Semua kontak'),
              ),
              ListTile(
                leading: Icon(Icons.person_off),
                title: Text('Kontak saya kecuali...'),
              ),
              ListTile(
                leading: Icon(Icons.people_alt),
                title: Text('Bagikan hanya dengan...'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CommunitiesPage extends StatefulWidget {
  const CommunitiesPage({super.key});

  @override
  State<CommunitiesPage> createState() => _CommunitiesPageState();
}

class _CommunitiesPageState extends State<CommunitiesPage> {
  final communities = <Map<String, String>>[];

  @override
  Widget build(BuildContext context) {
    final empty = communities.isEmpty;

    return NeoScaffold(
      title: 'Komunitas',
      actions: [
        PopupMenuButton<String>(
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'settings', child: Text('Pengaturan komunitas')),
            PopupMenuItem(value: 'help', child: Text('Bantuan')),
          ],
          onSelected: (value) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('$value dibuka')),
            );
          },
        ),
      ],
      child: empty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(25),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const NeoCard(
                      color: cyan,
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Icon(Icons.groups_rounded, size: 95),
                      ),
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'Tetap terhubung dengan komunitas',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Satukan anggota berdasarkan topik dan kelola pengumuman admin dengan tampilan yang ringan.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 22),
                    NeoButton(
                      text: 'Mulai komunitas Anda',
                      icon: Icons.add_rounded,
                      onPressed: _create,
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'Buat komunitas baru dari tombol di bawah.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black54,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                ...communities.map(
                  (community) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: NeoCard(
                      color: Colors.white,
                      child: ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const CircleAvatar(
                          backgroundColor: cyan,
                          child: Icon(Icons.groups, color: ink),
                        ),
                        title: Text(
                          community['name'] ?? 'Komunitas',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: Text(
                          community['desc'] ?? '',
                        ),
                        trailing: const Icon(Icons.chevron_right),
                      ),
                    ),
                  ),
                ),
                NeoButton(
                  text: 'Buat komunitas',
                  icon: Icons.add,
                  onPressed: _create,
                ),
              ],
            ),
      floatingActionButton: empty
          ? null
          : FloatingActionButton(
              backgroundColor: lime,
              foregroundColor: ink,
              elevation: 0,
              onPressed: _create,
              child: const Icon(Icons.add),
            ),
    );
  }

  void _create() {
    final name = TextEditingController();
    final desc = TextEditingController();

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: paper,
        title: const Text(
          'Komunitas baru',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(labelText: 'Nama'),
            ),
            TextField(
              controller: desc,
              decoration: const InputDecoration(labelText: 'Deskripsi'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              final communityName = name.text.trim();
              if (communityName.isNotEmpty) {
                setState(() {
                  communities.add({
                    'name': communityName,
                    'desc': desc.text.trim().isEmpty
                        ? 'Komunitas NeoTalk'
                        : desc.text.trim(),
                  });
                });
              }
              Navigator.pop(dialogContext);
            },
            child: const Text('Buat'),
          ),
        ],
      ),
    ).whenComplete(() {
      name.dispose();
      desc.dispose();
    });
  }
}

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});

  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  final recents = <String>[];

  @override
  Widget build(BuildContext context) {
    return NeoScaffold(
      title: 'Panggilan',
      actions: [
        IconButton(icon: const Icon(Icons.search), onPressed: () {}),
        PopupMenuButton<String>(
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'settings', child: Text('Pengaturan panggilan')),
          ],
          onSelected: (_) {},
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: lime,
        foregroundColor: ink,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(17),
          side: const BorderSide(color: ink, width: 3),
        ),
        onPressed: () => _startCall(false),
        icon: const Icon(Icons.add_call),
        label: const Text(
          'CALL',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _callAction(Icons.call, 'Telepon'),
                _callAction(Icons.calendar_month, 'Jadwal'),
                _callAction(Icons.dialpad, 'Keypad'),
                _callAction(Icons.groups, 'Grup'),
                _callAction(Icons.favorite, 'Favorit'),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'Terbaru',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          ...recents.asMap().entries.map(
            (entry) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: NeoCard(
                color: Colors.white,
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: entry.key.isEven ? lime : cyan,
                      child: Text(
                        entry.value.substring(0, 1),
                        style: const TextStyle(
                          color: ink,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            entry.value,
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                          const Text(
                            '↗ Hari ini 20.58',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => _startCall(false, name: entry.value),
                      icon: const Icon(Icons.call),
                    ),
                    IconButton(
                      onPressed: () => _startCall(true, name: entry.value),
                      icon: const Icon(Icons.videocam),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _callAction(IconData icon, String label) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: NeoCard(
        color: Colors.white,
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            CircleAvatar(
              backgroundColor: cyan,
              child: Icon(icon, color: ink),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ),
    );
  }

  void _startCall(bool video, {String name = 'Neo Contact'}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CallPage(name: name, video: video),
      ),
    );
  }
}

class CallPage extends StatefulWidget {
  final String name;
  final bool video;

  const CallPage({super.key, required this.name, required this.video});

  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  bool muted = false;
  bool speaker = false;
  bool camera = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ink,
      body: SafeArea(
        child: Stack(
          children: [
            if (widget.video)
              Positioned.fill(
                child: Container(
                  color: const Color(0xFF202020),
                  child: Center(
                    child: CircleAvatar(
                      radius: 70,
                      backgroundColor: cyan,
                      child: Text(
                        (widget.name.isNotEmpty ? widget.name.substring(0, 1) : "?"),
                        style: const TextStyle(
                          color: ink,
                          fontSize: 60,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            Positioned(
              top: 20,
              left: 20,
              right: 20,
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const Text(
                          'Menghubungkan…',
                          style: TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 35,
              left: 20,
              right: 20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _circle(
                    Icons.mic,
                    muted,
                    () => setState(() => muted = !muted),
                  ),
                  if (widget.video)
                    _circle(
                      Icons.videocam,
                      !camera,
                      () => setState(() => camera = !camera),
                    ),
                  _circle(
                    Icons.volume_up,
                    speaker,
                    () => setState(() => speaker = !speaker),
                  ),
                  _circle(
                    Icons.call_end,
                    false,
                    () => Navigator.pop(context),
                    red: true,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _circle(
    IconData icon,
    bool active,
    VoidCallback onTap, {
    bool red = false,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(50),
      child: CircleAvatar(
        radius: 29,
        backgroundColor: red
            ? pink
            : (active ? yellow : Colors.white24),
        child: Icon(
          icon,
          color: red || active ? ink : Colors.white,
        ),
      ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String user = 'Guest';
  String email = 'guest@example.com';

  @override
  void initState() {
    super.initState();
    Future.wait(<Future<String>>[
      LocalStore.username(),
      LocalStore.email(),
    ]).then((values) {
      if (!mounted) return;
      setState(() {
        user = values[0];
        email = values[1];
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = _settings();

    return NeoScaffold(
      title: 'Pengaturan',
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: const Icon(Icons.arrow_back),
      ),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          NeoCard(
            color: lime,
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 32,
                  backgroundColor: cyan,
                  child: Icon(Icons.person, color: ink, size: 32),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text(
                        email,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.qr_code_2, size: 35),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ...settings.map(
            (setting) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: NeoCard(
                color: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                onTap: () => _open(setting['title'].toString()),
                child: Row(
                  children: [
                    Container(
                      width: 43,
                      height: 43,
                      decoration: BoxDecoration(
                        color: setting['color'] as Color,
                        border: Border.all(color: ink, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        setting['icon'] as IconData,
                        color: ink,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            setting['title'].toString(),
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            setting['sub'].toString(),
                            style: const TextStyle(
                              color: Colors.black54,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          NeoButton(
            text: 'Keluar',
            icon: Icons.logout,
            color: pink,
            onPressed: _logout,
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _settings() {
    return <Map<String, dynamic>>[
      {
        'title': 'Langganan',
        'sub': 'Jelajahi keuntungan premium',
        'icon': Icons.workspace_premium,
        'color': yellow,
      },
      {
        'title': 'Perangkat tertaut',
        'sub': 'Gunakan NeoTalk di perangkat lain',
        'icon': Icons.devices,
        'color': cyan,
      },
      {
        'title': 'Akun',
        'sub': 'Notifikasi keamanan, ganti email',
        'icon': Icons.key,
        'color': lime,
      },
      {
        'title': 'Privasi',
        'sub': 'Akun diblokir, pesan sementara',
        'icon': Icons.lock,
        'color': pink,
      },
      {
        'title': 'Daftar',
        'sub': 'Kelola orang dan grup',
        'icon': Icons.contacts,
        'color': orange,
      },
      {
        'title': 'Chat',
        'sub': 'Riwayat obrolan, cadangan',
        'icon': Icons.chat_bubble_outline,
        'color': cyan,
      },
      {
        'title': 'Tampilan',
        'sub': 'Tema obrolan, ikon aplikasi, tema aplikasi',
        'icon': Icons.palette,
        'color': yellow,
      },
      {
        'title': 'Notifikasi',
        'sub': 'Pesan, grup & nada dering panggilan',
        'icon': Icons.notifications_none,
        'color': lime,
      },
      {
        'title': 'Penyimpanan dan data',
        'sub': 'Penggunaan jaringan, unduh otomatis',
        'icon': Icons.data_usage,
        'color': cyan,
      },
      {
        'title': 'Kontrol orang tua',
        'sub': 'Pengaturan untuk keluarga Anda',
        'icon': Icons.shield_outlined,
        'color': pink,
      },
    ];
  }

  void _open(String title) {
    if (title == 'Privasi') {
      showModalBottomSheet<void>(
        context: context,
        backgroundColor: paper,
        builder: (_) => const SafeArea(
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Privasi',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
                SizedBox(height: 12),
                ListTile(
                  leading: Icon(Icons.lock),
                  title: Text('Siapa yang dapat melihat profil saya'),
                ),
                ListTile(
                  leading: Icon(Icons.visibility),
                  title: Text('Terakhir dilihat & online'),
                ),
                ListTile(
                  leading: Icon(Icons.block),
                  title: Text('Kontak diblokir'),
                ),
              ],
            ),
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$title dibuka')),
      );
    }
  }

  Future<void> _logout() async {
    await LocalStore.logout();
    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => AuthScreen(
          onDone: () {
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const Shell()),
              (route) => false,
            );
          },
        ),
      ),
      (route) => false,
    );
  }
}

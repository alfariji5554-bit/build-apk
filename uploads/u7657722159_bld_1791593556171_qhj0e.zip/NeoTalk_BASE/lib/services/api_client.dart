import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class ApiClient {
  // Termux on the same Android device. Change this later to your HTTPS API.
  static const String baseUrl = String.fromEnvironment(
    'NEOTALK_API_URL',
    defaultValue: 'http://127.0.0.1:3000',
  );

  static Uri _uri(String path) => Uri.parse('$baseUrl$path');

  static Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    String? token,
  }) async {
    final headers = <String, String>{
      'Accept': 'application/json',
      if (body != null) 'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };

    late http.Response response;
    try {
      final uri = _uri(path);
      if (method == 'GET') {
        response = await http.get(uri, headers: headers).timeout(const Duration(seconds: 20));
      } else if (method == 'POST') {
        response = await http.post(uri, headers: headers, body: jsonEncode(body ?? const {})).timeout(const Duration(seconds: 20));
      } else if (method == 'PATCH') {
        response = await http.patch(uri, headers: headers, body: jsonEncode(body ?? const {})).timeout(const Duration(seconds: 20));
      } else if (method == 'PUT') {
        response = await http.put(uri, headers: headers, body: jsonEncode(body ?? const {})).timeout(const Duration(seconds: 20));
      } else if (method == 'DELETE') {
        response = await http.delete(uri, headers: headers).timeout(const Duration(seconds: 20));
      } else {
        throw ApiException('Metode API tidak didukung: $method');
      }
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Tidak dapat terhubung ke API $baseUrl. Pastikan server Termux sedang berjalan.');
    }

    dynamic decoded;
    try {
      decoded = response.body.isEmpty ? <String, dynamic>{} : jsonDecode(response.body);
    } catch (_) {
      throw ApiException('API mengembalikan respons yang tidak valid (${response.statusCode}).', statusCode: response.statusCode);
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map && decoded['message'] != null
          ? decoded['message'].toString()
          : 'Permintaan gagal (${response.statusCode}).';
      throw ApiException(message, statusCode: response.statusCode);
    }

    if (decoded is Map<String, dynamic>) return decoded;
    return <String, dynamic>{'data': decoded};
  }

  static Future<Map<String, dynamic>> register({
    required String username,
    required String email,
    required String password,
  }) {
    return _request('POST', '/api/auth/register', body: {
      'username': username,
      'email': email,
      'password': password,
    });
  }

  static Future<Map<String, dynamic>> login({
    required String identity,
    required String password,
  }) {
    return _request('POST', '/api/auth/login', body: {
      'identity': identity,
      'password': password,
    });
  }

  static Future<Map<String, dynamic>> me(String token) {
    return _request('GET', '/api/me', token: token);
  }
  static Future<Map<String, dynamic>> updateProfile(String token, {String? displayName, String? bio, String? avatarUrl}) {
    return _request('PATCH', '/api/me', token: token, body: {
      if (displayName != null) 'displayName': displayName,
      if (bio != null) 'bio': bio,
      if (avatarUrl != null) 'avatarUrl': avatarUrl,
    });
  }

  static Future<Map<String, dynamic>> searchUsers(String token, String query) =>
      _request('GET', '/api/users/search?q=${Uri.encodeQueryComponent(query)}', token: token);

  static Future<Map<String, dynamic>> conversations(String token) =>
      _request('GET', '/api/conversations', token: token);

  static Future<Map<String, dynamic>> createDirectConversation(String token, String userId) =>
      _request('POST', '/api/conversations/direct', token: token, body: {'userId': userId});

  static Future<Map<String, dynamic>> messages(String token, String conversationId) =>
      _request('GET', '/api/conversations/$conversationId/messages', token: token);

  static Future<Map<String, dynamic>> sendMessage(String token, String conversationId, {String text = '', String type = 'text', String? mediaUrl}) =>
      _request('POST', '/api/conversations/$conversationId/messages', token: token, body: {
        'text': text, 'type': type, if (mediaUrl != null) 'mediaUrl': mediaUrl,
      });
}

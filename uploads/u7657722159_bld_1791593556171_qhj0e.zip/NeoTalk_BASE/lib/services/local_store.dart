import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  static const _username = 'api_username';
  static const _email = 'api_email';
  static const _token = 'api_token';
  static const _loggedIn = 'api_logged_in';
  static const _privacy = 'status_privacy';

  static Future<SharedPreferences> get _prefs async => SharedPreferences.getInstance();

  static Future<void> saveSession({
    required String username,
    required String email,
    required String token,
  }) async {
    final p = await _prefs;
    await p.setString(_username, username);
    await p.setString(_email, email);
    await p.setString(_token, token);
    await p.setBool(_loggedIn, true);
  }

  static Future<bool> isLoggedIn() async {
    final p = await _prefs;
    return (p.getBool(_loggedIn) ?? false) && (p.getString(_token)?.isNotEmpty ?? false);
  }

  static Future<String?> token() async => (await _prefs).getString(_token);
  static Future<void> logout() async {
    final p = await _prefs;
    await p.remove(_token);
    await p.setBool(_loggedIn, false);
  }
  static Future<String> username() async => (await _prefs).getString(_username) ?? 'Guest';
  static Future<String> email() async => (await _prefs).getString(_email) ?? 'guest@example.com';
  static Future<void> setPrivacy(String value) async => (await _prefs).setString(_privacy, value);
  static Future<String> privacy() async => (await _prefs).getString(_privacy) ?? 'Semua kontak';
}

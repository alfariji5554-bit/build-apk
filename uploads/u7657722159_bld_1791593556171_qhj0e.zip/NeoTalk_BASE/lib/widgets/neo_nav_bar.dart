import 'dart:ui';

import 'package:flutter/material.dart';

class NeoNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final int chatBadge;

  const NeoNavBar({super.key, required this.currentIndex, required this.onTap, this.chatBadge = 0});

  @override
  Widget build(BuildContext context) {
    final items = <(IconData, String)>[
      (Icons.chat_bubble_rounded, 'Chat'),
      (Icons.auto_awesome_rounded, 'Pembaruan'),
      (Icons.groups_rounded, 'Komunitas'),
      (Icons.call_rounded, 'Panggilan'),
    ];
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(25),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: const Color(0xDDF5F0E6),
                border: Border.all(color: const Color(0xFF111111), width: 2.5),
                borderRadius: BorderRadius.circular(25),
                boxShadow: const [BoxShadow(color: Color(0xFF111111), offset: Offset(4, 5), blurRadius: 0)],
              ),
              child: Row(
                children: List.generate(items.length, (index) {
                  final active = index == currentIndex;
                  final icon = items[index].$1;
                  final label = items[index].$2;
                  return Expanded(
                    child: Semantics(
                      button: true,
                      selected: active,
                      label: label,
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => onTap(index),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeOutCubic,
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          padding: const EdgeInsets.symmetric(vertical: 9),
                          decoration: BoxDecoration(
                            color: active ? const Color(0xB39BE15D) : Colors.white.withValues(alpha: 0.12),
                            border: Border.all(color: active ? const Color(0xFF111111) : Colors.white.withValues(alpha: 0.35), width: active ? 2 : 1),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: active ? const [BoxShadow(color: Color(0x66111111), offset: Offset(2, 2), blurRadius: 0)] : null,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              AnimatedScale(
                                scale: active ? 1.08 : 1.0,
                                duration: const Duration(milliseconds: 260),
                                curve: Curves.easeOutBack,
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Icon(icon, size: active ? 25 : 23, color: const Color(0xFF111111)),
                                    if (index == 0 && chatBadge > 0)
                                      Positioned(
                                        right: -9,
                                        top: -8,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                          decoration: BoxDecoration(color: const Color(0xFFFF5A5F), border: Border.all(color: const Color(0xFF111111), width: 1.5), shape: BoxShape.circle),
                                          child: Text('$chatBadge', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900)),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, color: const Color(0xFF111111), fontWeight: active ? FontWeight.w900 : FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
